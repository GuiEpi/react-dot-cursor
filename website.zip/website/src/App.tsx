import { useState } from 'react'
import ReactDotCursorLogo from '/react-dot-cursor.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <div>
        <a href="https://react-dot-cursor.guics.st" target="_blank">
          <img src={ReactDotCursorLogo} className='logo' alt="Vite logo" />
        </a>
      </div>
      <h1>React dot Cursor</h1>
      <p>An opinionated cursor component for React.</p>
      <div className="card">
        <button onClick={() => setCount((count) => count + 1)}>
          count is {count}
        </button>
      </div>
      <a className="read-the-docs">
        Read the documentation
      </a>
    </>
  )
}

export default App
